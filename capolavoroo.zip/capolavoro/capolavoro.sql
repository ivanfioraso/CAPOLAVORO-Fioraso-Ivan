-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 29, 2025 alle 20:07
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capolavoro`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `carrello`
--

CREATE TABLE `carrello` (
  `id_carrello` int(11) NOT NULL,
  `id_utente` int(11) DEFAULT NULL,
  `id_destinazione` int(11) DEFAULT NULL,
  `data_partenza` date DEFAULT NULL,
  `data_ritorno` date DEFAULT NULL,
  `numero_persone` int(11) DEFAULT NULL,
  `prezzo_totale` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `carrello`
--

INSERT INTO `carrello` (`id_carrello`, `id_utente`, `id_destinazione`, `data_partenza`, `data_ritorno`, `numero_persone`, `prezzo_totale`) VALUES
(3, 2, 1, '2025-04-03', '2025-04-17', 2, 0.00),
(4, 3, 3, '2025-04-04', '2025-04-10', 8, 0.00),
(5, 2, 1, '2025-05-21', '2025-05-27', 3, 0.00),
(11, 2, 9, '2025-07-21', '2025-10-31', 1, 0.00),
(13, 7, 2, '2025-06-26', '2025-09-26', 1, 0.00),
(14, 8, 21, '2025-05-26', '2025-12-26', 1, 0.00),
(16, 1, 5, '2025-05-26', '2025-05-31', 4, 1340.00),
(17, 1, 9, '2025-05-27', '2025-06-27', 3, 7161.00);

-- --------------------------------------------------------

--
-- Struttura della tabella `destinazioni`
--

CREATE TABLE `destinazioni` (
  `id_destinazione` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `descrizione` text DEFAULT NULL,
  `tipologia` varchar(20) DEFAULT NULL,
  `prezzo` decimal(10,2) DEFAULT NULL,
  `immagine` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `destinazioni`
--

INSERT INTO `destinazioni` (`id_destinazione`, `nome`, `descrizione`, `tipologia`, `prezzo`, `immagine`) VALUES
(1, 'Roma', 'La Capitale d\'Italia con storia millenaria.', 'città', 150.00, '../public/assets/roma.jpeg'),
(2, 'Parigi', 'La città dell\'amore e della Torre Eiffel.', 'città', 200.00, '../public/assets/parigi.jpeg'),
(3, 'Barcellona', 'Cultura catalana e spiagge fantastiche.', 'città', 180.00, '../public/assets/barcellona.jpeg'),
(4, 'New York', 'Una metropoli piena di vita e opportunità.', 'città', 300.00, '../public/assets/NY.jpeg'),
(5, 'Paphos', 'Città cipriota ricca di storia e spiagge cristalline.', 'mare', 67.00, '../public/assets/paphos.jpeg'),
(6, 'Costa del Sol', 'Famosa costa spagnola con clima soleggiato e spiagge dorate.', 'mare', 70.00, '../public/assets/costa_del_sol.jpeg'),
(7, 'Mombasa', 'Città costiera keniota con influenze arabe e spiagge tropicali.', 'città', 65.00, '../public/assets/mombasa.jpeg'),
(8, 'Funchal', 'Capoluogo di Madeira, noto per i suoi giardini e paesaggi montuosi.', 'mare', 75.00, '../public/assets/funchal.jpeg'),
(9, 'Sliema', 'Località maltese con lungomare vivace e architettura storica.', 'mare', 77.00, '../public/assets/sliema.jpeg'),
(10, 'Orlando', 'Città americana famosa per i suoi parchi a tema e attrazioni.', 'città', 80.00, '../public/assets/orlando.jpeg'),
(11, 'Praga', 'Capitale ceca con architettura gotica e atmosfera romantica.', 'città', 79.00, '../public/assets/praga.jpeg'),
(12, 'Lanzarote', 'Isola delle Canarie con paesaggi vulcanici e spiagge uniche.', 'mare', 85.00, '../public/assets/lanzarote.jpeg'),
(13, 'Grand Baie', 'Località mauriziana con acque turchesi e vita notturna.', 'mare', 86.00, '../public/assets/grand_baie.jpeg'),
(14, 'Phuket', 'Isola thailandese con spiagge paradisiache e cultura vibrante.', 'mare', 87.00, '../public/assets/phuket.jpeg'),
(15, 'Budapest', 'Capitale ungherese con terme storiche e architettura maestosa.', 'città', 88.00, '../public/assets/budapest.jpeg'),
(16, 'Faro', 'Città portoghese tranquilla con centro storico affascinante.', 'mare', 39.00, '../public/assets/faro.jpeg'),
(17, 'Bali', 'Isola indonesiana famosa per le sue spiagge e templi.', 'mare', 40.00, '../public/assets/bali.jpeg'),
(18, 'Sofia', 'Capitale bulgara con ricca storia e prezzi accessibili.', 'città', 38.00, '../public/assets/sofia.jpeg'),
(19, 'Sharm El Sheikh', 'Resort egiziano con barriere coralline e deserto.', 'mare', 37.00, '../public/assets/sharm_el_sheikh.jpeg'),
(20, 'Antalya', 'Città turca con rovine antiche e spiagge sabbiose.', 'città', 32.00, '../public/assets/antalya.jpeg'),
(21, 'Zanzibar', 'Arcipelago tropicale con acque cristalline e cultura swahili.', 'mare', 45.00, '../public/assets/zanzibar.jpeg'),
(22, 'Hoi An', 'Città vietnamita con lanterne colorate e atmosfera storica.', 'città', 50.00, '../public/assets/hoi_an.jpeg'),
(23, 'Tirana', 'Capitale albanese emergente con prezzi bassi e paesaggi unici.', 'città', 36.00, '../public/assets/tirana.jpeg'),
(24, 'Palawan', 'Isola filippina con lagune smeraldo e scogliere spettacolari.', 'mare', 52.00, '../public/assets/palawan.jpeg');

-- --------------------------------------------------------

--
-- Struttura della tabella `recensioni`
--

CREATE TABLE `recensioni` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) DEFAULT NULL,
  `cognome` varchar(100) DEFAULT NULL,
  `voto` int(11) DEFAULT NULL CHECK (`voto` between 1 and 5),
  `commento` text DEFAULT NULL,
  `data_inserimento` timestamp NOT NULL DEFAULT current_timestamp(),
  `email` varchar(150) DEFAULT NULL,
  `destinazione` varchar(100) DEFAULT NULL,
  `titolo` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `recensioni`
--

INSERT INTO `recensioni` (`id`, `nome`, `cognome`, `voto`, `commento`, `data_inserimento`, `email`, `destinazione`, `titolo`) VALUES
(1, 'Luca', 'Rossi', 5, 'Viaggio indimenticabile, tutto perfetto! Grazie IvanTrip!', '2024-05-01 08:30:00', 'luca.rossi@example.com', 'Malaga', 'Esperienza perfetta'),
(2, 'Sara', 'Bianchi', 4, 'Buon servizio, ma volo in ritardo.', '2024-05-03 13:20:00', 'sara.bianchi@example.com', 'Atene', 'Tutto ok'),
(3, 'Giulia', 'Verdi', 3, 'Destinazione fantastica, ma hotel deludente.', '2024-05-05 07:00:00', 'giulia.verdi@example.com', 'Lisbona', 'Bella città'),
(4, 'Matteo', 'Gallo', 5, 'Tutto organizzato nei minimi dettagli, ci tornerò!', '2024-05-06 16:10:00', 'matteo.gallo@example.com', 'Parigi', 'Perfetto!'),
(5, 'Elena', 'Neri', 2, 'Supporto clienti poco reattivo. Bella città, ma disguidi.', '2024-05-08 10:40:00', 'elena.neri@example.com', 'Praga', 'Disorganizzazione'),
(6, 'Francesco', 'Russo', 4, 'Hotel top, escursioni ben gestite.', '2024-05-10 15:00:00', 'francesco.russo@example.com', 'Barcellona', 'Vacanza da rifare'),
(7, 'Martina', 'Colombo', 5, 'Esperienza meravigliosa, abbiamo adorato ogni momento!', '2024-05-12 18:15:00', 'martina.colombo@example.com', 'Dubai', 'Viaggio da sogno'),
(8, 'Alessandro', 'Conti', 3, 'Servizio buono ma migliorabile, soprattutto i trasporti.', '2024-05-13 11:05:00', 'alessandro.conti@example.com', 'Amsterdam', 'Nella media'),
(9, 'Chiara', 'Marino', 4, 'Cibo fantastico e clima perfetto. Ottimo consiglio della segretaria.', '2024-05-14 08:50:00', 'chiara.marino@example.com', 'Tenerife', 'Ottima esperienza'),
(10, 'Davide', 'Greco', 5, 'Abbiamo prenotato con la consulenza e ci siamo trovati benissimo!', '2024-05-15 09:30:00', 'davide.greco@example.com', 'Tokyo', 'Un viaggio da ricordare'),
(11, 'Poto', 'Potino', 5, 'bella destinazione, servizio eccellente', '2025-05-26 06:29:59', 'potos@gmail.com', 'Parigi', 'Wesh'),
(12, 'MIotto', 'Andrea', 5, 'Bello ma troppo fumo', '2025-05-26 06:53:59', 'andrymiotto06@gmail.com', 'Auschwitz', 'Troppo gas');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `nome`, `cognome`, `email`, `password`, `created_at`) VALUES
(1, 'Ivan', 'Fioraso', 'ivanfioraso0@gmail.com', '$2y$10$tGB78DpJTfcqKFjAJNaHbuEnyNZBA1poNr564cFOI4DNrisHyBHPe', '2025-05-14 13:23:35'),
(2, 'luigi', 'bianchi', 'luigibianchi43@gmail.com', '$2y$10$B2xRGYSCiNx.JeJMjGhFMuLy80.xvN9K1t8e3EKRgVroHFYdUuVdi', '2025-05-14 13:24:45'),
(3, 'mario', 'rossi', 'mariorossi0@gmail.com', '$2y$10$Vx4PKUSXuCdno.xpc4hYU.QvqASIFunFIIupuTVBUnoRz.cGDpo.y', '2025-05-14 13:25:12'),
(4, 'aurora', 'ringhia', 'auroraringhia03@gmail.com', '$2y$10$dnH.drZDgDS8MPqNnv0LK.RFymhIzhyBYuAW6W2dSzIXjYfgZQON.', '2025-05-14 13:26:01'),
(5, 'marco', 'fioraso', 'marcofioraso1489@gmail.com', '$2y$10$R/2oYvA6ha0GMxY7r.0XW.7uxuyUCAwX9nXxxf8dNA.4NW6tgkmMq', '2025-05-14 19:35:00'),
(6, 'gianni', 'moroni', 'gianni435@gmail.com', '$2y$10$QVR3Y9Sxxo1aibx2lX8Cbet.l8Lr6xAHS.q0SLi9UjTC41g0Vw1TK', '2025-05-19 16:11:00'),
(7, 'poto', 'potino', 'potos@gmail.com', '$2y$10$P8UnlmoVdoYaWnPDQ1FkMexScSruNYuQQDmcij4za9glnedtTOj0K', '2025-05-26 06:26:43'),
(8, 'paolo', 'soster', 'paolososter@gmail.com', '$2y$10$bIjdmYTiWpl8/Yj8wPcOWeJlC71bZtoGyLfoaX/q1R8ihX0/sziMy', '2025-05-26 06:47:25'),
(9, 'alessio', 'ferraretto', 'sasa@gmail.com', '$2y$10$a3qhqt1Wu4UmRIzU8fv70uV46ECKKtmK9wAWJc0VFENRtzodjStzS', '2025-05-26 07:22:02');

-- --------------------------------------------------------

--
-- Struttura della tabella `viaggi_effettuati`
--

CREATE TABLE `viaggi_effettuati` (
  `id_viaggio` int(11) NOT NULL,
  `id_utente` int(11) DEFAULT NULL,
  `id_destinazione` int(11) DEFAULT NULL,
  `data_partenza` date DEFAULT NULL,
  `data_ritorno` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `viaggi_effettuati`
--

INSERT INTO `viaggi_effettuati` (`id_viaggio`, `id_utente`, `id_destinazione`, `data_partenza`, `data_ritorno`) VALUES
(1, 1, 1, '2024-07-10', '2024-07-15'),
(2, 1, 3, '2024-08-20', '2024-08-25'),
(3, 2, 2, '2024-06-05', '2024-06-10'),
(4, 3, 4, '2024-09-01', '2024-09-07');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `carrello`
--
ALTER TABLE `carrello`
  ADD PRIMARY KEY (`id_carrello`),
  ADD KEY `id_utente` (`id_utente`),
  ADD KEY `id_destinazione` (`id_destinazione`);

--
-- Indici per le tabelle `destinazioni`
--
ALTER TABLE `destinazioni`
  ADD PRIMARY KEY (`id_destinazione`);

--
-- Indici per le tabelle `recensioni`
--
ALTER TABLE `recensioni`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indici per le tabelle `viaggi_effettuati`
--
ALTER TABLE `viaggi_effettuati`
  ADD PRIMARY KEY (`id_viaggio`),
  ADD KEY `id_utente` (`id_utente`),
  ADD KEY `id_destinazione` (`id_destinazione`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `carrello`
--
ALTER TABLE `carrello`
  MODIFY `id_carrello` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT per la tabella `destinazioni`
--
ALTER TABLE `destinazioni`
  MODIFY `id_destinazione` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT per la tabella `recensioni`
--
ALTER TABLE `recensioni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT per la tabella `viaggi_effettuati`
--
ALTER TABLE `viaggi_effettuati`
  MODIFY `id_viaggio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `carrello`
--
ALTER TABLE `carrello`
  ADD CONSTRAINT `carrello_ibfk_1` FOREIGN KEY (`id_utente`) REFERENCES `utenti` (`id`),
  ADD CONSTRAINT `carrello_ibfk_2` FOREIGN KEY (`id_destinazione`) REFERENCES `destinazioni` (`id_destinazione`);

--
-- Limiti per la tabella `viaggi_effettuati`
--
ALTER TABLE `viaggi_effettuati`
  ADD CONSTRAINT `viaggi_effettuati_ibfk_1` FOREIGN KEY (`id_utente`) REFERENCES `utenti` (`id`),
  ADD CONSTRAINT `viaggi_effettuati_ibfk_2` FOREIGN KEY (`id_destinazione`) REFERENCES `destinazioni` (`id_destinazione`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
