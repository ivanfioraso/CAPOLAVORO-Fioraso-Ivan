<?php
session_start();
require_once('../../backend/config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nome = $_POST['nome'];
  $cognome = $_POST['cognome'];
  $voto = $_POST['voto'];
  $titolo = $_POST['titolo'];
  $commento = $_POST['commento'];
  $email = $_POST['email'];
  $destinazione = $_POST['destinazione'];

  $stmt = $conn->prepare("INSERT INTO recensioni (nome, cognome, voto, commento, email, destinazione, titolo, data_inserimento) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
  $stmt->execute([$nome, $cognome, $voto, $commento, $email, $destinazione, $titolo]);
}

$recensioni = $conn->query("SELECT * FROM recensioni ORDER BY data_inserimento DESC");
?>

<!DOCTYPE html>
<html lang="it">

<head>
  <meta charset="UTF-8">
  <title>Recensioni dei Viaggiatori</title>
  <link rel="stylesheet" href="../../public/css/recensioni.css">
</head>

<body>
  <header>
    <h1>Recensioni dei Viaggiatori</h1>
    <p>Scopri cosa pensano i nostri clienti delle loro esperienze!</p>
  </header>

  <main>
    <section class="reviews">
      <?php foreach ($recensioni as $r): ?>
        <div class="review-card">
          <h2><?= htmlspecialchars($r['titolo']) ?></h2>
          <div class="meta">
            <span><strong><?= htmlspecialchars($r['nome']) ?> <?= htmlspecialchars($r['cognome']) ?></strong></span>
            <span><?= htmlspecialchars($r['destinazione']) ?> - <?= date("d/m/Y", strtotime($r['data_inserimento'])) ?></span>
            <span class="rating"><?= str_repeat("⭐", $r['voto']) ?> (<?= $r['voto'] ?>/5)</span>
          </div>
          <p><?= nl2br(htmlspecialchars($r['commento'])) ?></p>
        </div>
      <?php endforeach; ?>
    </section>

    <section class="review-form">
      <h2>Lascia una Recensione</h2>
      <form method="POST">
        <input type="text" name="nome" placeholder="Nome" required>
        <input type="text" name="cognome" placeholder="Cognome" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="destinazione" placeholder="Destinazione" required>
        <input type="text" name="titolo" placeholder="Titolo della recensione" required>
        <select name="voto" required>
          <option value="">Voto</option>
          <?php for ($i = 5; $i >= 1; $i--): ?>
            <option value="<?= $i ?>"><?= $i ?> stelle</option>
          <?php endfor; ?>
        </select>
        <textarea name="commento" rows="5" placeholder="Scrivi qui la tua recensione..." required></textarea>
        <button type="submit">Invia Recensione</button>
      </form>
    </section>
  </main>

  <footer>
    <p>&copy; <?= date('Y') ?> IvanTrip - Tutti i diritti riservati</p>
  </footer>
</body>

</html>