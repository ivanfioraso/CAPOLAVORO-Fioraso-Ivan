<?php
session_start();

require_once('../../backend/config.php');

$result = $conn->query("SELECT * FROM destinazioni");
$recensioni = $conn->query("SELECT nome, cognome, voto, titolo, commento, destinazione FROM recensioni ORDER BY data_inserimento DESC LIMIT 10");
?>






<!DOCTYPE html>
<html lang="it">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IvanTrip - Agenzia di Viaggi</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="../../public/css/home.style.css" />
  <link rel="icon" href="../../public/assets/logo.png" type="image/png">
  <style>
    body {
      font-family: Arial, sans-serif;
      height: auto;
      margin: 0;
      padding: 0;
      background-color: #f4f4f4;
      background-image: url("../../public/assets/fotoisola2.jpg");
      background-size: 100% 100%;
      background-position: center;
      background-repeat: no-repeat;
      background-attachment: fixed;
      display: flex;
      flex-direction: column;
      align-items: center;
    }

    .navbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: linear-gradient(90deg, rgba(34, 193, 195, 0.9), rgba(253, 187, 45, 0.8));
      color: white;
      padding: 15px 40px;
      margin: 20px 20px;
      border-radius: 20px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
      position: sticky;
      width: 90%;
      top: 0;
      z-index: 1000;
    }

    .navbar .logo {
      display: flex;
      align-items: center;
      padding-left: 40px;
    }

    .navbar .logo i {
      font-size: 24px;
      margin-right: 10px;
    }

    .navbar .logo span {
      font-size: 24px;
      font-weight: bold;
    }

    .navbar .buttons {
      display: flex;
      gap: 10px;
    }

    .navbar .buttons button {
      background: linear-gradient(to right, #00c9ff, #92fe9d);

      color: #ffffff;
      border: none;
      padding: 10px 20px;
      border-radius: 5px;
      font-size: 16px;
      cursor: pointer;
    }

    .navbar .buttons button:hover {
      background: linear-gradient(to right, #92fe9d, #00c9ff);
    }

    .carousel-container {
      position: relative;
      width: 90%;
      max-width: 100%;
      margin-top: 10px;
      overflow: hidden;
      height: 200px;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: transparent;
    }

    @media (max-width: 768px) {
      .carousel-container {
        height: 250px;
      }

      .carousel-item {
        width: 200px;
        margin-right: 10px;
      }

      .footer-container {
        flex-direction: column;
        align-items: center;
      }
    }

    .carousel {
      display: flex;
      animation: scroll 20s linear infinite;
      width: calc(300px * 16 + 20px * 15);
    }

    .carousel-item {
      flex: 0 0 auto;
      width: 270px;
      height: 70%;
      margin-right: 20px;
      overflow: hidden;
    }

    .carousel-item img {
      width: 100%;
      height: 80%;
      object-fit: cover;

      border-radius: 8px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    @keyframes scroll {
      0% {
        transform: translateX(0);
      }

      100% {
        transform: translateX(-50%);
      }
    }

    /* Sezione Footer */
    .footer {
      text-align: center;
      padding: 20px;
      background-color: rgba(51, 51, 51, 0.8);
      color: white;
      width: 100%;
    }

    .intro {
      margin: 40px auto;
      margin-top: 10px;
      padding: 60px 30px;
      max-width: 700px;
      background: rgba(255, 255, 255, 0.5);
      border-radius: 20px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
      text-align: center;
      color: #fff;
      background-image: linear-gradient(135deg, rgba(86, 203, 242, 0.75) 0%, rgba(47, 129, 237, 0.75) 100%);
      transition: all 0.3s ease-in-out;
    }

    .intro h1 {
      font-size: 42px;
      font-weight: 400;
      margin-bottom: 10px;
      color: #fff;
    }

    .intro h1 span {
      color: #a7ffeb;
      font-weight: 700;
    }

    .intro h1 small {
      font-size: 22px;
      display: block;
      margin-top: 8px;
      color: #d0f0ff;
    }

    .intro p {
      font-size: 18px;
      line-height: 1.6;
      color: #e9faff;
      max-width: 700px;
      margin: 20px auto 30px;
    }

    .intro button {
      background: linear-gradient(to right, #00c9ff, #92fe9d);
      color: #003147;
      padding: 14px 32px;
      font-size: 18px;
      font-weight: 600;
      border: none;
      border-radius: 50px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .intro button:hover {
      background: linear-gradient(to right, #92fe9d, #00c9ff);
    }

    .footer {
      background: linear-gradient(135deg, #2F80ED, #56CCF2);
      color: white;
      padding: 40px 20px 20px;
      font-size: 15px;
      margin-top: 50px;
      border-radius: 40px 40px 0 0;
    }

    .footer-container {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
      max-width: 1200px;
      margin: auto;
    }

    .footer-column {
      flex: 1;
      min-width: 200px;
      margin: 10px;
    }

    .footer-column h3,
    .footer-column h4 {
      font-size: 18px;
      margin-bottom: 15px;
      color: #a7ffeb;
    }

    .footer-column ul {
      list-style: none;
      padding: 0;
    }

    .footer-column ul li {
      margin-bottom: 8px;
    }

    .footer-column ul li a {
      text-decoration: none;
      color: #e9faff;
      transition: color 0.3s;
    }

    .footer-column ul li a:hover {
      color: #ffffff;
      text-decoration: underline;
    }

    .social-icons a {
      color: white;
      margin-right: 10px;
      font-size: 20px;
      transition: color 0.3s;
    }

    .social-icons a:hover {
      color: #00c9ff;
    }

    .footer-bottom {
      text-align: center;
      margin-top: 30px;
      font-size: 14px;
      color: #d0f0ff;
    }

    .cookie-banner {
      position: fixed;
      bottom: 0;
      left: 0;
      right: 0;
      background-color: rgba(0, 0, 0, 0.85);
      color: #fff;
      padding: 15px 20px;
      font-size: 14px;
      text-align: center;
      z-index: 9999;
      display: none;
      font-family: 'Arial', sans-serif;
      box-shadow: 0 -3px 10px rgba(0, 0, 0, 0.5);
      border-top: 4px solid #FFD700;
    }

    .cookie-banner p {
      margin: 0;
      padding: 0;
      font-size: 16px;
    }

    .cookie-banner a {
      color: #FFD700;
      text-decoration: none;
      font-weight: bold;
    }

    .cookie-banner a:hover {
      text-decoration: underline;
    }

    .cookie-banner button {
      background-color: #4CAF50;
      color: white;
      border: none;
      padding: 12px 25px;
      font-size: 14px;
      cursor: pointer;
      border-radius: 5px;
      margin-left: 20px;
      transition: background-color 0.3s ease;
    }

    .cookie-banner button:hover {
      background-color: #45a049;
    }

    @media (max-width: 768px) {
      .cookie-banner {
        padding: 10px 15px;
        font-size: 14px;
      }

      .cookie-banner button {
        font-size: 12px;
        padding: 8px 18px;
      }

      .cookie-banner p {
        font-size: 14px;
      }
    }


    .special-offers {
      max-width: 1050px;
      margin: 10px auto;
      padding: 40px 20px;
    }

    .special-offers div {
      display: flex;
      align-items: start;
      justify-content: center;
      gap: 16px;

    }

    .special-offers div h2 {

      font-size: 2rem;
      margin-bottom: 30px;
      text-align: center;
      color: #333;
      font-weight: 700;
    }

    .offers-container {
      display: flex;
      flex-wrap: wrap;
      gap: 30px;
      justify-content: center;
    }

    .card {
      position: relative;
      width: 300px;
      height: 400px;
      background: white;
      border-radius: 15px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      cursor: pointer;
      overflow: hidden;
      transition: box-shadow 0.3s ease;
      display: flex;
      flex-direction: column;
    }

    .card:hover {
      box-shadow: 0 18px 36px rgba(0, 0, 0, 0.25);
    }

    .imgBox {
      position: relative;
      height: 100%;
      border-radius: 15px;
      overflow: hidden;
      transition: height 0.4s ease, border-radius 0.4s ease;
    }

    .card:hover .imgBox {
      height: 160px;
      width: 100%;
      border-radius: 15px 15px 0 0;
    }

    .imgBox img {
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 2s linear, border-radius 0.4s ease;
      border-radius: inherit;
      display: block;
    }

    .card:hover .imgBox img {
      transform: scale(0.95);
    }

    .content {
      padding: 20px;
      padding-bottom: 60px;
      flex-grow: 1;
      opacity: 0;
      max-height: 0;
      overflow: hidden;
      transition: opacity 0.3s ease 0.3s, max-height 0.4s ease 0.3s;
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
    }

    .card:hover .content {
      opacity: 1;
      max-height: 500px;
    }

    .content h2 {
      margin: 0 0 10px 0;
      font-size: 1.3rem;
      color: var(--clr);
    }

    .content p {
      margin: 0 0 10px 0;
      color: #555;
      font-size: 1rem;
      line-height: 1.4;
      flex-grow: 1;
    }

    .price {
      font-weight: 700;
      color: var(--clr);
      font-size: 1.1rem;
      margin-bottom: 10px;
    }

    .btn {
      position: absolute;
      bottom: 15px;
      left: 50%;
      transform: translateX(-50%);
      background-color: var(--clr);
      color: white;
      padding: 12px 28px;
      font-weight: 600;
      border-radius: 30px;
      text-decoration: none;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.25);
      transition: background-color 0.3s ease;
      z-index: 10;
    }

    .btn:hover {
      background-color: #000000bb;
    }

    @media (max-width: 650px) {
      .offers-container {
        flex-direction: column;
        align-items: center;
        gap: 25px;
      }

      .card {
        width: 90vw;
        height: auto;
        min-height: 400px;
      }

      .imgBox {
        height: 180px !important;
        border-radius: 15px 15px 0 0 !important;
      }

      .content {
        padding: 15px 20px 60px 20px;
      }
    }

    .card-button {
      position: absolute;
      bottom: 15px;
      left: 50%;
      transform: translateX(-50%);
      background-color: var(--clr);
      color: white;
      padding: 10px 24px;
      border: none;
      border-radius: 30px;
      cursor: pointer;
      font-weight: bold;
      font-size: 1rem;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
      z-index: 10;
      transition: background-color 0.3s ease;
    }

    .card-button:hover {
      background-color: #000000cc;
    }

    .ultime-recensioni {
      background: rgba(224, 247, 250, 0);
      padding: 3rem 2rem;
      border-radius: 12px;
      margin-top: 4rem;
    }

    .ultime-recensioni h2 {
      text-align: center;
      color: #00695c;
      margin-bottom: 2.5rem;
      font-size: 2rem;
    }

    .recensioni-flex {
      display: flex;
      flex-wrap: wrap;
      gap: 2rem;
      justify-content: center;
    }

    .recensione-card {
      flex: 0 0 calc(50% - 2rem);
      box-sizing: border-box;
      background-color: #ffffff;
      padding: 1.5rem;
      border-radius: 12px;
      border-left: 6px solid #00bfa5;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      min-height: 100px;
    }

    .recensione-card:hover {
      transform: translateY(-5px);
    }

    .recensione-card h3 {
      margin-top: 0;
      font-size: 1.3rem;
      color: #00796b;
    }

    .recensione-card .meta {
      font-size: 0.95rem;
      color: #555;
      margin-bottom: 0.8rem;
    }

    .recensione-card .voto {
      color: #ffb300;
    }

    .recensione-card .commento {
      font-style: italic;
      color: #333;
      line-height: 1.5;
      max-height: 100px;
      overflow: auto;
      padding-right: 5px;
    }


    .btn-recensioni {
      background-color: #00796b;
      color: white;
      padding: 0.7rem 1.5rem;
      border-radius: 8px;
      text-decoration: none;
      font-weight: bold;
      transition: background-color 0.3s;
    }

    .btn-recensioni:hover {
      background-color: #004d40;
    }

    .titolo-recensioni {
      display: inline-block;
      background-color: rgba(0, 255, 247, 0.64);
      color: white;
      padding: 5px;
      border-radius: 6px;
      text-align: center;
      margin: 0 auto;
    }

    .contenitore-titolo {
      text-align: center;
    }
  </style>


</head>

<body>
  <div class="navbar">
    <div class="logo">
      <a href="../../frontend/html/home.php" style="display: flex; align-items: center; text-decoration: none; color: inherit;">
        <img src="../../public/assets/logo.png" alt="Logo" style="width: 48px; height: 48px; margin-right: 10px;">
        <span>IvanTrip - Viaggia Giovane</span>
      </a>
    </div>
    <?php if (isset($_SESSION['utente_id'])): ?>
      <a href="../../backend/profilo.php" class="profilo-icon" title="Profilo">
        <img href="../../backend/profilo.php" src="../../public/assets/user.png" alt="Profilo" style="width: 35px; height: 35px; border-radius: 50%; object-fit: cover;">
      </a>
    <?php else: ?>
      <div class="buttons">
        <button onclick="window.location.href='../../frontend/html/login.html'">Accedi</button>
        <button onclick="window.location.href='../../frontend/html/register.html'">Registrati</button>
      </div>
    <?php endif; ?>
  </div>

  <div class="carousel-container">
    <div class="carousel">
      <div class="carousel-item"><img src="../../public/assets/gg.jpg" alt="Foto 1"></div>
      <div class="carousel-item"><img src="../../public/assets/neve.jpg" alt="Foto 2"></div>
      <div class="carousel-item"><img src="../../public/assets/download.jpeg" alt="Foto 3"></div>
      <div class="carousel-item"><img src="../../public/assets/mont.jpg" alt="Foto 4"></div>
      <div class="carousel-item"><img src="../../public/assets/isolla.webp" alt="Foto 5"></div>
      <div class="carousel-item"><img src="../../public/assets/cas.jpeg" alt="Foto 6"></div>
      <div class="carousel-item"><img src="../../public/assets/neva.avif" alt="Foto 7"></div>
      <div class="carousel-item"><img src="../../public/assets/tropic.jpeg" alt="Foto 8"></div>

      <div class="carousel-item"><img src="../../public/assets/gg.jpg" alt="Foto 1"></div>
      <div class="carousel-item"><img src="../../public/assets/neve.jpg" alt="Foto 2"></div>
      <div class="carousel-item"><img src="../../public/assets/download.jpeg" alt="Foto 3"></div>
      <div class="carousel-item"><img src="../../public/assets/mont.jpg" alt="Foto 4"></div>
      <div class="carousel-item"><img src="../../public/assets/isolla.webp" alt="Foto 5"></div>
      <div class="carousel-item"><img src="../../public/assets/cas.jpeg" alt="Foto 6"></div>
      <div class="carousel-item"><img src="../../public/assets/neva.avif" alt="Foto 7"></div>
      <div class="carousel-item"><img src="../../public/assets/tropic.jpeg" alt="Foto 8"></div>

      <div class="carousel-item"><img src="../../public/assets/gg.jpg" alt="Foto 1"></div>
      <div class="carousel-item"><img src="../../public/assets/neve.jpg" alt="Foto 2"></div>
      <div class="carousel-item"><img src="../../public/assets/download.jpeg" alt="Foto 3"></div>
      <div class="carousel-item"><img src="../../public/assets/mont.jpg" alt="Foto 4"></div>
      <div class="carousel-item"><img src="../../public/assets/isolla.webp" alt="Foto 5"></div>
      <div class="carousel-item"><img src="../../public/assets/cas.jpeg" alt="Foto 6"></div>
      <div class="carousel-item"><img src="../../public/assets/neva.avif" alt="Foto 7"></div>
      <div class="carousel-item"><img src="../../public/assets/tropic.jpeg" alt="Foto 8"></div>

      <div class="carousel-item"><img src="../../public/assets/gg.jpg" alt="Foto 1"></div>
      <div class="carousel-item"><img src="../../public/assets/neve.jpg" alt="Foto 2"></div>
      <div class="carousel-item"><img src="../../public/assets/download.jpeg" alt="Foto 3"></div>
      <div class="carousel-item"><img src="../../public/assets/mont.jpg" alt="Foto 4"></div>
      <div class="carousel-item"><img src="../../public/assets/isolla.webp" alt="Foto 5"></div>
      <div class="carousel-item"><img src="../../public/assets/cas.jpeg" alt="Foto 6"></div>
      <div class="carousel-item"><img src="../../public/assets/neva.avif" alt="Foto 7"></div>
      <div class="carousel-item"><img src="../../public/assets/tropic.jpeg" alt="Foto 8"></div>

      <div class="carousel-item"><img src="../../public/assets/gg.jpg" alt="Foto 1"></div>
      <div class="carousel-item"><img src="../../public/assets/neve.jpg" alt="Foto 2"></div>
      <div class="carousel-item"><img src="../../public/assets/download.jpeg" alt="Foto 3"></div>
      <div class="carousel-item"><img src="../../public/assets/mont.jpg" alt="Foto 4"></div>
      <div class="carousel-item"><img src="../../public/assets/isolla.webp" alt="Foto 5"></div>
      <div class="carousel-item"><img src="../../public/assets/cas.jpeg" alt="Foto 6"></div>
      <div class="carousel-item"><img src="../../public/assets/neva.avif" alt="Foto 7"></div>
      <div class="carousel-item"><img src="../../public/assets/tropic.jpeg" alt="Foto 8"></div>
    </div>
  </div>
  <div class="intro">
    <div class="intro-content">
      <h1>
        <?php if (isset($_SESSION['utente_id'])): ?>
          <?= htmlspecialchars($_SESSION['utente_nome']) ?>
        <?php endif; ?>
        Benvenuto su <span class="brand">IvanTrip</span><br>

        <small>La tua prossima avventura ti aspetta</small>
      </h1>
      <p>
        Scopri destinazioni mozzafiato, offerte imperdibili e pacchetti su misura per ogni tipo di viaggiatore.
        Dai tropici innevati alle città romantiche: IvanTrip è il tuo passaporto per il mondo.
      </p>
      <button onclick="window.location.href='../../backend/scopridestinazioni.php'">
        ✨ Esplora le Destinazioni
      </button>
    </div>
  </div>



  <section class="special-offers">
    <div>
      <img style="width: 50px; height:50px" src="../../public/assets/world.gif" alt="">
      <h2> Offerte Speciali </h2>
      <img style="width: 50px; height:50px" src="../../public/assets/world.gif" alt="">
    </div>
    <br>


    <div class="offers-container">

      <div class="card" style="--clr:#00A896">
        <div class="imgBox">
          <img src="../../public/assets/tropic.jpeg" alt="Spiagge Tropicali">
        </div>
        <div class="content">
          <h2>Spiagge Tropicali</h2>
          <p>7 notti all-inclusive in resort 5★ alle Maldive. Volo incluso.</p>
          <span class="price">Da €1.499</span>
        </div>
        <button class="card-button" onclick="window.location.href='../../frontend/html/offerta2.html'">Scopri di più</button>
      </div>

      <div class="card" style="--clr:#F25F5C">
        <div class="imgBox">
          <img src="../../public/assets/romantica.jpeg" alt="Weekend Romantico">
        </div>
        <div class="content">
          <h2>Weekend Romantico</h2>
          <p>2 notti in hotel boutique a Parigi con cena gourmet e crociera sulla Senna.</p>
          <span class="price">Da €599</span>
        </div>
        <button class="card-button" onclick="window.location.href='../../frontend/html/offerta1.html'">Scopri di più</button>
      </div>

      <div class="card" style="--clr:#247BA0">
        <div class="imgBox">
          <img src="../../public/assets/montagna.jpeg" alt="Avventura in Montagna">
        </div>
        <div class="content">
          <h2>Avventura in Montagna</h2>
          <p>5 giorni di trekking guidato sulle Dolomiti con pernottamento in rifugi.</p>
          <span class="price">Da €799</span>
        </div>
        <button class="card-button" onclick="window.location.href='../../frontend/html/offerta3.html'">Scopri di più</button>
      </div>

      <div class="card" style="--clr:#FFB400">
        <div class="imgBox">
          <img src="../../public/assets/caption.jpg" alt="Tour Culturale">
        </div>
        <div class="content">
          <h2>Tour Culturale</h2>
          <p>Tour guidato di 7 giorni tra le città d'arte italiane con guide esperte.</p>
          <span class="price">Da €1.199</span>
        </div>
        <button class="card-button" onclick="window.location.href='../../frontend/html/offerta4.html'">Scopri di più</button>
      </div>

      <div class="card" style="--clr:#1B998B">
        <div class="imgBox">
          <img src="../../public/assets/safari.jpg" alt="Safari in Africa">
        </div>
        <div class="content">
          <h2>Safari in Africa</h2>
          <p>10 giorni in lodge di lusso tra Kenya e Tanzania con safari giornalieri.</p>
          <span class="price">Da €2.499</span>
        </div>
        <button class="card-button" onclick="window.location.href='../../frontend/html/offerta5.html'">Scopri di più</button>
      </div>

      <div class="card" style="--clr:#6A0572">
        <div class="imgBox">
          <img src="../../public/assets/boreale.jpeg" alt="Aurora Boreale in Islanda">
        </div>
        <div class="content">
          <h2>Aurora Boreale in Islanda</h2>
          <p>4 notti in hotel con escursioni serali per ammirare l'aurora boreale.</p>
          <span class="price">Da €1.299</span>
        </div>
        <button class="card-button" onclick="window.location.href='../../frontend/html/offerta6.html'">Scopri di più</button>
      </div>


    </div>
  </section>


  <section class="ultime-recensioni">
    <div class="contenitore-titolo">
      <h2 class="titolo-recensioni">🌟 Cosa dicono i nostri viaggiatori</h2>
    </div>
    <div class="recensioni-flex">
      <?php foreach ($recensioni as $r): ?>
        <div class="recensione-card">
          <h3><?= htmlspecialchars($r['titolo']) ?></h3>
          <p class="meta">
            <strong><?= htmlspecialchars($r['nome']) ?> <?= htmlspecialchars($r['cognome']) ?></strong> –
            <em><?= htmlspecialchars($r['destinazione']) ?></em> –
            <span class="voto">⭐ <?= htmlspecialchars($r['voto']) ?>/5</span>
          </p>
          <p class="commento"><?= nl2br(htmlspecialchars($r['commento'])) ?></p>
        </div>
      <?php endforeach; ?>
    </div>


  </section>
  <div style="text-align: center; margin-top: 2rem;">
    <a href="recensioni.php" class="btn-recensioni">Leggi tutte le recensioni</a>
  </div>



  <div>
    <br>
  </div>
  <footer class="footer">
    <div class="footer-container">
      <div class="footer-column">
        <h3>IvanTrip</h3>
        <p>La tua prossima avventura inizia da qui. Scopri il mondo con noi, in modo semplice e sicuro.</p>
      </div>

      <div class="footer-column">
        <h4>Esplora</h4>
        <ul>
          <li><a href="../../backend/scopridestinazioni.php">Destinazioni</a></li>
          <li><a href="../../frontend/html/offerte.html">Offerte</a></li>
          <li><a href="../../frontend/html/prenotazioni.html">Prenotazioni</a></li>
          <li><a href="../../frontend/html/recensioni.php">Recensioni</a></li>
        </ul>
      </div>

      <div class="footer-column">
        <h4>Info Utili</h4>
        <ul>
          <li><a href="../html/chisiamo.html">Chi siamo</a></li>
          <li><a href="../../frontend/html/contatti.html">Contatti</a></li>
          <li><a href="../../frontend/html/privacy.html">Privacy Policy</a></li>
          <li><a href="../../frontend/html/termini_condizioni.html">Termini e Condizioni</a></li>
        </ul>
      </div>

      <div class="footer-column">
        <h4>Seguici</h4>
        <div class="social-icons">
          <a href="#"><i class="fab fa-facebook-f"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-youtube"></i></a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      <p>&copy; 2025 IvanTrip. Tutti i diritti riservati.</p>
    </div>
  </footer>

  <div id="cookie-banner" class="cookie-banner">
    <p>
      Questo sito utilizza i cookie per migliorare l'esperienza. <a href="#">Leggi di più</a>
      <button id="accept-cookies" class="btn-accept">Accetta</button>
    </p>
  </div>

  <script>
    function checkCookieConsent() {
      const consent = getCookie("cookie-consent");
      if (!consent) {
        document.getElementById("cookie-banner").style.display = "block";
      }
    }

    function getCookie(name) {
      const value = `; ${document.cookie}`;
      const parts = value.split(`; ${name}=`);
      if (parts.length === 2) return parts.pop().split(";").shift();
      return null;
    }

    function setCookie(name, value, days) {
      const date = new Date();
      date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
      const expires = `expires=${date.toUTCString()}`;
      document.cookie = `${name}=${value}; ${expires}; path=/`;
    }

    document.getElementById("accept-cookies").addEventListener("click", function() {
      setCookie("cookie-consent", "accepted", 365);
      document.getElementById("cookie-banner").style.display = "none";
    });

    checkCookieConsent();
  </script>

</body>

</html>