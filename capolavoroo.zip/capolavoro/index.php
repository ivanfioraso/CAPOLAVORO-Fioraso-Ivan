<?php

header("location:./frontend/html/home.php");

?>