<?php
session_start();
require_once('config.php');
require '../../vendor/autoload.php'; // PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';

    if (empty($email)) {
        $error = "Inserisci la tua email.";
    } else {
        // Controlla se esiste utente con questa email
        $stmt = $conn->prepare("SELECT * FROM utenti WHERE email = ?");
        $stmt->execute([$email]);
        $utente = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$utente) {
            $error = "Email non registrata.";
        } else {
            // Genera codice 6 cifre
            $codice = random_int(100000, 999999);
            $_SESSION['codice_recupero'] = $codice;
            $_SESSION['email_recupero'] = $email;
            $_SESSION['codice_expire'] = time() + 300; // 5 minuti

            // Invia email con PHPMailer
            $mail = new PHPMailer(true);

            try {
                //Server settings
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'tuoindirizzo@gmail.com'; // Cambia con tua email
                $mail->Password = 'tuapasswordapp'; // Usa password app Gmail
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 587;

                //Recipients
                $mail->setFrom('tuoindirizzo@gmail.com', 'IvanTrip');
                $mail->addAddress($email, $utente['nome']);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Codice di Recupero Password IvanTrip';
                $mail->Body = "Ciao " . htmlspecialchars($utente['nome']) . ",<br><br>Il tuo codice per recuperare la password è: <b>$codice</b><br>Valido per 5 minuti.<br><br>Se non hai richiesto questo codice, ignora questa email.";

                $mail->send();

                // Reindirizza alla pagina verifica codice
                header("Location: verifica_codice.php");
                exit();

            } catch (Exception $e) {
                $error = "Errore invio email: {$mail->ErrorInfo}";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="../public/css/stileunico.css" />
    <title>Recupera Password - Inserisci Email</title>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <a href="home.php" style="display: flex; align-items: center; text-decoration: none; color: inherit;">
                <img src="../public/assets/logo.png" alt="Logo" />
                <span>IvanTrip</span>
            </a>
        </div>
    </div>

    <div class="login-container">
        <h2>Recupera Password</h2>
        <?php if (!empty($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form action="" method="POST">
            <input type="email" name="email" placeholder="Inserisci la tua email" required />
            <br /><br />
            <button type="submit">Invia Codice</button>
        </form>
    </div>
</body>
</html>
