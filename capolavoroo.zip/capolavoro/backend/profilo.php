<?php
session_start();
require_once('../backend/config.php');
if (!isset($_SESSION['utente_id'])) {
    header("Location: login.php");
    exit();
}

$id = $_SESSION['utente_id'];

$stmt = $conn->prepare("SELECT * FROM utenti WHERE id = ?");
$stmt->execute([$id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "Errore: utente non trovato!";
    exit();
}

if (!isset($_SESSION['utente_id'])) {
    header("Location: ../frontend/html/login.html");
    exit();
}

// Carrello
$stmt = $conn->prepare("
    SELECT c.*, d.nome, d.prezzo, d.immagine 
    FROM carrello c 
    JOIN destinazioni d ON c.id_destinazione = d.id_destinazione
    WHERE c.id_utente = ?
    ORDER BY c.id_carrello DESC
");
$stmt->execute([$id]);
$carrello = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Viaggi effettuati
$stmt = $conn->prepare("
    SELECT d.nome, d.immagine, v.data_partenza, v.data_ritorno 
    FROM viaggi_effettuati v 
    JOIN destinazioni d ON v.id_destinazione = d.id_destinazione 
    WHERE v.id_utente = ?
");
$stmt->execute([$id]);
$viaggi_effettuati = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['elimina_carrello'])) {
    $id_carrello = intval($_POST['id_carrello']);
    $stmt = $conn->prepare("DELETE FROM carrello WHERE id_carrello = :id_carrello AND id_utente = :id_utente");
    $stmt->bindParam(':id_carrello', $id_carrello, PDO::PARAM_INT);
    $stmt->bindParam(':id_utente', $id, PDO::PARAM_INT);
    $stmt->execute();

    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}



?>




<!DOCTYPE html>
<html lang="it">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="../public/css/profilo.css" />
    <title>Profilo Utente - IvanTrip</title>
    <link rel="icon" href="../public/assets/logo.png" type="image/png">
</head>

<body>

    <div class="navbar">
        <div class="logo">
            <a href=" ../frontend/html/home.php "
                style="display: flex; align-items: center; text-decoration: none; color: inherit;">
                <img src="../public/assets/logo.png" alt="Logo">

            </a>
        </div>
        <div class="buttons">
            <button onclick="window.location.href='logout.php'">Esci</button>
        </div>
    </div>

    <div class="profile-container">
        <div class="welcome-box">
            <div class="welcome-content">
                <img src="../public/assets/user.png" alt="Foto Profilo" class="profile-pic">
                <h2>Benvenuto, <?= htmlspecialchars($user['nome']) ?>!</h2>
            </div>
        </div>


        <div class="profile-main">

            <div class="profile-top">
                <div class="section profile-info">
                    <h3>Dati Personali</h3>
                    <div class="data-grid">
                        <div class="data-item"><i class="fas fa-user"></i> Nome: <?= htmlspecialchars($user['nome']) ?></div>
                        <div class="data-item"><i class="fas fa-user"></i> Cognome: <?= htmlspecialchars($user['cognome']) ?></div>
                        <div class="data-item"><i class="fas fa-envelope"></i> Email: <?= htmlspecialchars($user['email']) ?></div>
                        <div class="data-item">Profilo creato il: <?= htmlspecialchars($user['created_at']) ?></div>
                    </div>
                </div>

                <div class="section profile-edit">
                    <h3>Modifica Dati</h3>
                    <form action="update_profile.php" method="POST" class="form-container">
                        <label for="nome">Nome</label>
                        <input id="nome" type="text" name="nome" value="<?= htmlspecialchars($user['nome']) ?>" placeholder="Nome" required>

                        <label for="cognome">Cognome</label>
                        <input id="cognome" type="text" name="cognome" value="<?= htmlspecialchars($user['cognome']) ?>" placeholder="Cognome" required>

                        <label for="email">Email</label>
                        <input id="email" type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" placeholder="Email" required>

                        <label for="password">Nuova password (opzionale)</label>
                        <input id="password" type="password" name="password" placeholder="Nuova password">

                        <button type="submit" class="btn-update">Aggiorna</button>
                    </form>
                </div>

            </div>

            <div class="profile-bottom">
                <div class="section carrello">
                    <h3>Il tuo Carrello</h3>
                    <?php if (!empty($carrello)): ?>
                        <div class="data-grid">
                            <?php foreach ($carrello as $item): ?>
                                <div class="data-item">
                                    <br>
                                    <img src="<?= htmlspecialchars($item['immagine']) ?>" alt="<?= htmlspecialchars($item['nome']) ?>" style="max-width: 150px;">
                                    <br><br>
                                    <i class="fas fa-shopping-cart"></i>
                                    <?= htmlspecialchars($item['nome']) ?> - €<?= number_format($item['prezzo_totale'], 2) ?>
                                    <br>
                                    <small>
                                        Partenza: <?= htmlspecialchars($item['data_partenza']) ?><br>
                                        Ritorno: <?= htmlspecialchars($item['data_ritorno']) ?><br>
                                        Persone: <?= intval($item['numero_persone']) ?>
                                    </small>
                                    <br>
                                    <form method="POST" onsubmit="return confirm('Sei sicuro di voler rimuovere questo elemento dal carrello?');">
                                        <input type="hidden" name="id_carrello" value="<?= intval($item['id_carrello']) ?>">
                                        <button type="submit" name="elimina_carrello" class="btn-elimina">Elimina</button>
                                    </form>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p>Nessun elemento nel carrello.</p>
                    <?php endif; ?>
                </div>

                <div class="section viaggi-effettuati">
                    <h3>Viaggi Passati</h3>
                    <?php if (!empty($viaggi_effettuati)): ?>
                        <div class="data-grid">
                            <?php foreach ($viaggi_effettuati as $viaggio): ?>
                                <div class="data-item">
                                    <br>
                                    <img src="<?= htmlspecialchars($viaggio['immagine']) ?>" alt="<?= htmlspecialchars($viaggio['nome']) ?>">
                                    <br><br>
                                    <i class="fas fa-suitcase-rolling"></i>
                                    <?= htmlspecialchars($viaggio['nome']) ?> - Dal <?= htmlspecialchars($viaggio['data_partenza']) ?> al <?= htmlspecialchars($viaggio['data_ritorno']) ?>
                                    <br>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <p>Nessun viaggio effettuato.</p>
                    <?php endif; ?>
                </div>
            </div>

        </div>



</body>

</html>