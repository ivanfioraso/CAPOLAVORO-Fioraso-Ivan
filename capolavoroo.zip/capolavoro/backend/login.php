<?php
session_start();
require_once('config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        die("Email e password sono obbligatorie.");
    }

    $stmt = $conn->prepare("SELECT * FROM utenti WHERE email = ?");
    $stmt->execute([$email]);
    $utente = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($utente && password_verify($password, $utente['password'])) {
        $_SESSION['utente_id'] = $utente['id'];
        $_SESSION['utente_email'] = $utente['email'];
        $_SESSION['utente_nome'] = $utente['nome'];

        header("Location: profilo.php");
        exit();
    } else {
        echo "Email o password non validi.";
    }
} else {
    echo "Metodo di richiesta non valido.";
}
?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel="stylesheet" href="../public/css/stileunico.css" />
    <title>Login</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet" />
    <link rel="icon" href="../public/assets/logo.png" type="image/png" />
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <a href="home.php" style="display: flex; align-items: center; text-decoration: none; color: inherit;">
                <img src="../public/assets/logo.png" alt="Logo" />
                <span>IvanTrip</span>
            </a>
        </div>
        <div class="buttons">
            <button onclick="window.location.href='../frontend/html/login.html'">Accedi</button>
            <button onclick="window.location.href='../frontend/html/register.html'">Registrati</button>
        </div>
    </div>

    <div class="login-container">
        <h2>Login</h2>
        <form action="../../backend/login.php" method="POST">
            <input type="email" id="email" name="email" placeholder="Inserisci la tua email" required /><br />
            <input type="password" id="password" name="password" placeholder="Inserisci la tua password" required /><br /><br />
            <button type="submit">Accedi</button>
        </form>
        <p style="margin-top: 15px;">
            Non sei ancora registrato?
            <a href="../frontend/html/register.html" style="color:#4CAF50;">Registrati qui</a>
        </p>
        <p>
            <a href="forgot_password.php" style="color:#4CAF50;">Hai dimenticato la password?</a>
        </p>
    </div>
</body>
</html>
