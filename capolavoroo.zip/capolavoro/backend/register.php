<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once('config.php');

echo "Arrivato prima del controllo POST";

if (
    isset($_POST['email']) &&
    isset($_POST['nome']) &&
    isset($_POST['cognome']) &&
    isset($_POST['password'])
) {
    $email = trim($_POST['email']);
    $nome = trim($_POST['nome']);
    $cognome = trim($_POST['cognome']);
    $password = $_POST['password'];
    $created_at = date('Y-m-d H:i:s');
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    echo "<pre>";
    print_r([
        'nome' => $nome,
        'cognome' => $cognome,
        'email' => $email,
        'password' => $password,
        'created_at' => $created_at
    ]);
    echo "</pre>";

    $stmt = $conn->prepare("SELECT id FROM utenti WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        echo "❌ Email già registrata!";
    } else {
        $stmt = $conn->prepare("INSERT INTO utenti (nome, cognome, email, password, created_at)
                                VALUES (:nome, :cognome, :email, :password, :created_at)");
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':cognome', $cognome);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':password', $password_hash);
        $stmt->bindParam(':created_at', $created_at);

        echo "Query SQL: INSERT INTO utenti (nome, cognome, email, password, created_at) VALUES ('$nome', '$cognome', '$email', '$password_hash', '$created_at')";

        if ($stmt->execute()) {
            echo "✅ Registrazione avvenuta con successo!";
            header('Location: ../frontend/html/login.html');
        } else {
            $errorInfo = $stmt->errorInfo();
            echo "❌ Errore durante la registrazione: " . $errorInfo[2];
        }
    }
} else {
    echo "⚠️ Compila tutti i campi richiesti.";
}
