<?php
session_start();

if (!isset($_SESSION['checkout'])) {
  header('Location: home.php');
  exit();
}

$checkout = $_SESSION['checkout'];

$prezzo_totale = $checkout['prezzo'] * $checkout['numero_persone'];
?>

<!DOCTYPE html>
<html lang="it">

<head>
  <meta charset="UTF-8">
  <title>Checkout - IvanTrip</title>
  <link rel="stylesheet" href="../public/css/stile_checkout.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap">
  <style>
    body {
      font-family: 'Montserrat', sans-serif;
      background: #f9f9f9;
      margin: 0;
      padding: 0;
    }

    .navbar {
      background: #004aad;
      color: white;
      padding: 15px 30px;
      display: flex;
      align-items: center;
    }

    .navbar .logo {
      color: white;
      text-decoration: none;
      font-weight: 600;
      font-size: 1.5em;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .navbar .logo img {
      height: 40px;
    }

    .container {
      max-width: 900px;
      margin: 40px auto;
      background: white;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 4px 10px rgb(0 0 0 / 0.1);
    }

    h1 {
      margin-bottom: 30px;
      color: #004aad;
    }

    .checkout-info {
      display: flex;
      gap: 30px;
      margin-bottom: 30px;
      align-items: center;
    }

    .checkout-info img {
      width: 250px;
      border-radius: 8px;
      object-fit: cover;
    }

    .details {
      flex: 1;
    }

    .details p {
      font-size: 1.1em;
      margin: 8px 0;
    }

    .price {
      font-weight: 700;
      font-size: 1.3em;
      color: #007b00;
      margin-top: 15px;
    }

    .buttons {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      margin-top: 40px;
    }

    .btn-pay {
      flex: 1 1 200px;
      padding: 15px 25px;
      font-size: 1.1em;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      transition: background-color 0.3s ease;
      box-shadow: 0 3px 6px rgb(0 0 0 / 0.15);
      user-select: none;
    }

    .btn-pay:disabled {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .btn-apple {
      background: black;
    }

    .btn-apple:hover {
      background: #222;
    }

    .btn-google {
      background: #4285f4;
    }

    .btn-google:hover {
      background: #357ae8;
    }

    .btn-card {
      background: #007bff;
    }

    .btn-card:hover {
      background: #0056b3;
    }

    .btn-back {
      margin-top: 30px;
      background: transparent;
      color: #004aad;
      border: 2px solid #004aad;
      padding: 12px 25px;
      font-weight: 600;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.2s ease, color 0.2s ease;
    }

    .btn-back:hover {
      background: #004aad;
      color: white;
    }
  </style>
</head>

<body>

  <div class="navbar">
    <a href="home.php" class="logo">
      <img src="../public/assets/logo.png" alt="Logo">
      IvanTrip
    </a>
  </div>

  <div class="container">
    <h1>Riepilogo pagamento</h1>

    <div class="checkout-info">
      <img src="<?= htmlspecialchars($checkout['immagine']) ?>" alt="Immagine destinazione">
      <div class="details">
        <p><strong>Destinazione:</strong> <?= htmlspecialchars($checkout['destinazione']) ?></p>
        <p><strong>Data di partenza:</strong> <?= htmlspecialchars($checkout['data_partenza']) ?></p>
        <p><strong>Data di ritorno:</strong> <?= htmlspecialchars($checkout['data_ritorno']) ?></p>
        <p><strong>Numero di persone:</strong> <?= htmlspecialchars($checkout['numero_persone']) ?></p>
        <p class="price">Prezzo totale: €<?= number_format($prezzo_totale, 2) ?></p>
      </div>
    </div>

    <div>
      <button class="btn-pay btn-apple" onclick="alert('Pagamento Apple Pay NON disponibile in questa demo.')">
        🍎 Apple Pay
      </button>
      <button class="btn-pay btn-google" onclick="alert('Pagamento Google Pay NON disponibile in questa demo.')">
        🤖 Google Pay
      </button>
      <button class="btn-pay btn-card" onclick="alert('Pagamento con carta di credito NON disponibile in questa demo.')">
        💳 Carta di credito
      </button>
    </div>

    <button class="btn-back" onclick="window.history.back()">← Torna indietro</button>
  </div>

</body>

</html>