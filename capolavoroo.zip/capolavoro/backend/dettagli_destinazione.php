<?php
session_start();
include 'config.php';

if (!isset($_SESSION['utente_id'])) {
  header('Location: ../login.php');
  exit();
}

$user_id = $_SESSION['utente_id'];
$success = "";
$error = "";

if (isset($_GET['id'])) {
  $id_destinazione = intval($_GET['id']);
  $query = $conn->prepare("SELECT * FROM destinazioni WHERE id_destinazione = ?");
  $query->execute([$id_destinazione]);
  $destinazione = $query->fetch(PDO::FETCH_ASSOC);

  if (!$destinazione) {
    die("Destinazione non trovata.");
  }
} else {
  die("Destinazione non trovata.");
}

// Gestione POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $data_partenza = $_POST['data_partenza'] ?? '';
  $data_ritorno = $_POST['data_ritorno'] ?? '';
  $numero_persone = intval($_POST['numero_persone'] ?? 1);
  $oggi = date("Y-m-d");

  if (!$data_partenza || !$data_ritorno) {
    $error = "Inserisci sia la data di partenza che di ritorno.";
  } elseif ($data_partenza < $oggi) {
    $error = "La data di partenza non può essere nel passato.";
  } elseif ($data_ritorno <= $data_partenza) {
    $error = "La data di ritorno deve essere successiva alla partenza.";
  } elseif ($numero_persone < 1) {
    $error = "Inserisci un numero valido di persone.";
  } else {
    $giorni = (strtotime($data_ritorno) - strtotime($data_partenza)) / (60 * 60 * 24);
    $prezzo_totale = $destinazione['prezzo'] * $numero_persone * $giorni;

    $stmt = $conn->prepare("INSERT INTO carrello (id_utente, id_destinazione, data_partenza, data_ritorno, numero_persone, prezzo_totale) VALUES (?, ?, ?, ?, ?, ?)");
    $success = $stmt->execute([$user_id, $id_destinazione, $data_partenza, $data_ritorno, $numero_persone, $prezzo_totale]);

    if ($success) {
      $_SESSION['checkout'] = [
        'destinazione' => $destinazione['nome'],
        'prezzo' => $destinazione['prezzo'],
        'data_partenza' => $data_partenza,
        'data_ritorno' => $data_ritorno,
        'numero_persone' => $numero_persone,
        'prezzo_totale' => $prezzo_totale,
        'immagine' => $destinazione['immagine']
      ];
      header("Location: checkout.php");
      exit();
    } else {
      $error = "Errore durante l'aggiunta al carrello.";
    }
  }
}
?>



<!DOCTYPE html>
<html lang="it">

<head>
  <meta charset="UTF-8">

  <title><?= htmlspecialchars($destinazione['nome']) ?> - Dettagli</title>
  <link rel="stylesheet" href="../public/css/stile_dettagli.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap">
  <!-- Flatpickr CSS stile iOS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
  <!-- Tema iOS-like -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/themes/material_blue.css">


</head>
<style>
  .rolldate-container {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background-color: #ffffff;
    border-radius: 10px;
  }
</style>

<body>
  <div class="navbar">
    <a href="../frontend/html/home.php" class="logo">
      <img src="../public/assets/logo.png" alt="Logo">
      <span>IvanTrip</span>
    </a>

    <?php if (isset($_SESSION['utente_id'])): ?>
      <div class="ctn">
        <a href="../backend/profilo.php" class="profilo-icon" title="Profilo">
          <img href="../backend/profilo.php" src="../public/assets/user.png" alt="Profilo">
        </a>
        <span>Profilo</span>
      </div>
    <?php else: ?>
      <div class="buttons">
        <button onclick="window.location.href='../../frontend/html/login.html'">Accedi</button>
        <button onclick="window.location.href='../../frontend/html/register.html'">Registrati</button>
      </div>
    <?php endif; ?>
  </div>

  <div class="dettaglio-container">
    <div class="img-section">
      <img src="<?= htmlspecialchars($destinazione['immagine']) ?>" alt="Immagine destinazione">
    </div>
    <div class="info-section">
      <h1><?= htmlspecialchars($destinazione['nome']) ?> - €<?= number_format($destinazione['prezzo'], 2) ?> / notte</h1>
      <p class="descrizione"><?= htmlspecialchars($destinazione['descrizione']) ?></p>

      <form class="form-prenota" method="POST">
        <label for="data_partenza">Data di partenza:</label>
        <input id="data_partenza" name="data_partenza" required>

        <label for="data_ritorno">Data di ritorno:</label>
        <input id="data_ritorno" name="data_ritorno" required>

        <label for="numero_persone">Numero di persone:</label>
        <input type="text" id="numero_persone" name="numero_persone" readonly placeholder="Seleziona numero">

        <p id="prezzoTotale" style="margin-top: 10px; font-weight: bold;">Totale: €0.00</p>

        <button type="submit">Aggiungi al carrello</button>
      </form>

      <?php if ($success): ?>
        <div class="success">
          Viaggio aggiunto al carrello!<br>
          Totale: €<?= number_format($prezzo_totale, 2) ?> (<?= $numero_persone ?> persone × <?= $giorni ?> notti × €<?= number_format($destinazione['prezzo'], 2) ?>)
        </div>
      <?php elseif ($error): ?>
        <div class="error"><?= $error ?></div>
      <?php endif; ?>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/rolldate@3.1.2/dist/rolldate.min.js"></script>

  <script>
    const prezzoUnitario = <?= floatval($destinazione['prezzo']) ?>;
    const inputNumeroPersone = document.getElementById('numero_persone');
    const inputPartenza = document.getElementById('data_partenza');
    const inputRitorno = document.getElementById('data_ritorno');
    const prezzoTotale = document.getElementById('prezzoTotale');

    function aggiornaPrezzo() {
      const persone = parseInt(inputNumeroPersone.value);
      const partenza = new Date(inputPartenza.value);
      const ritorno = new Date(inputRitorno.value);

      if (!isNaN(persone) && partenza && ritorno && ritorno > partenza) {
        const giorni = Math.round((ritorno - partenza) / (1000 * 60 * 60 * 24));
        const totale = prezzoUnitario * persone * giorni;
        prezzoTotale.textContent = `Totale: €${totale.toFixed(2)} (${persone} persone × ${giorni} notti × €${prezzoUnitario})`;
      } else {
        prezzoTotale.textContent = "Totale: €0.00";
      }
    }

    inputNumeroPersone.addEventListener('input', aggiornaPrezzo);
    inputPartenza.addEventListener('change', aggiornaPrezzo);
    inputRitorno.addEventListener('change', aggiornaPrezzo);
  </script>

  <script>
    new Rolldate({
      el: '#data_partenza',
      format: 'YYYY-MM-DD',
      beginYear: 2024,
      endYear: 2030,
      lang: {
        title: 'Partenza',
        cancel: 'Annulla',
        confirm: 'OK',
        year: '',
        month: '',
        day: ''
      }
    });

    new Rolldate({
      el: '#data_ritorno',
      format: 'YYYY-MM-DD',
      beginYear: 2024,
      endYear: 2030,
      lang: {
        title: 'Ritorno',
        cancel: 'Annulla',
        confirm: 'OK',
        year: '',
        month: '',
        day: ''
      }
    });

    new Rolldate({
      el: '#numero_persone',
      format: 'YYYY',
      beginYear: 1,
      endYear: 20,
      value: '1',
      lang: {
        title: 'Numero persone',
        cancel: 'Annulla',
        confirm: 'Conferma',
        year: '',
        month: '',
        day: ''
      },
      init: function() {
        document.querySelectorAll('.rolldate-panel .rolldate-content:nth-child(n+2)').forEach(e => e.style.display = 'none');
        const ul = document.querySelector('.rolldate-panel .rolldate-content ul');
        if (ul) ul.scrollTop = 0;
      },
      confirm: function(val) {
        document.querySelector('#numero_persone').value = val;
        aggiornaPrezzo();
      }
    });
  </script>
</body>

</html>