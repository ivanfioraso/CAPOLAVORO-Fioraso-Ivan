<?php
session_start();

if (!isset($_SESSION['codice_recupero']) || !isset($_SESSION['codice_expire']) || !isset($_SESSION['email_recupero'])) {
    header("Location: forgot_password.php");
    exit();
}

$errore = "";
$successo = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $codice_inserito = $_POST['codice'] ?? '';

    if (time() > $_SESSION['codice_expire']) {
        $errore = "Il codice è scaduto. <a href='forgot_password.php'>Richiedi un nuovo codice</a>.";
        session_unset();
    } elseif ($codice_inserito == $_SESSION['codice_recupero']) {
        $_SESSION['codice_verificato'] = true;
        header("Location: reset_password.php");
        exit();
    } else {
        $errore = "Codice non valido.";
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="../public/css/login.css" />
    <title>Verifica Codice</title>
    <script>
    let countdown = <?php echo ($_SESSION['codice_expire'] - time()) > 0 ? ($_SESSION['codice_expire'] - time()) : 0; ?>;
    function updateCountdown() {
        if (countdown <= 0) {
            document.getElementById("countdown").innerText = "Codice scaduto.";
            document.getElementById("submitBtn").disabled = true;
            return;
        }
        let min = Math.floor(countdown / 60);
        let sec = countdown % 60;
        document.getElementById("countdown").innerText = `Tempo rimanente: ${min}:${sec < 10 ? "0" + sec : sec}`;
        countdown--;
        setTimeout(updateCountdown, 1000);
    }
    window.onload = updateCountdown;
    </script>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <a href="home.php" style="display: flex; align-items: center; text-decoration: none; color: inherit;">
                <img src="../public/assets/logo.png" alt="Logo" />
                <link rel="stylesheet" href="../public/css/stileunico.css" />

                <span>IvanTrip</span>
            </a>
        </div>
    </div>

    <div class="login-container">
        <h2>Verifica Codice</h2>
        <?php if ($errore) echo "<p style='color:red;'>$errore</p>"; ?>
        <form method="POST">
            <input type="text" name="codice" placeholder="Inserisci il codice ricevuto via email" required autofocus />
            <p id="countdown" style="font-weight:bold; color:#4CAF50;"></p>
            <br />
            <button type="submit" id="submitBtn">Verifica</button>
        </form>
    </div>
</body>
</html>
