<?php
session_start();
require_once 'config.php';

$per_page = 9;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $per_page;

$conditions = [];
$params = [];


if (!empty($_GET['tipologia'])) {
  $conditions[] = "tipologia = :tipologia";
  $params[':tipologia'] = $_GET['tipologia'];
}
if (!empty($_GET['budget'])) {
  $budget = $_GET['budget'];
  if ($budget == "- €500") {
    $conditions[] = "prezzo < 500";
  } elseif ($budget == "€500 - €1000") {
    $conditions[] = "prezzo >= 500 AND prezzo <= 1000";
  } elseif ($budget == "€1000+") {
    $conditions[] = "prezzo > 1000";
  }
}

$where = '';
if (!empty($conditions)) {
  $where = "WHERE " . implode(" AND ", $conditions);
}

$count_stmt = $conn->prepare("SELECT COUNT(*) FROM destinazioni $where");
$count_stmt->execute($params);
$total_destinazioni = $count_stmt->fetchColumn();
$total_pages = ceil($total_destinazioni / $per_page);


$sql = "SELECT * FROM destinazioni $where ORDER BY id_destinazione ASC LIMIT :start, :per_page";
$stmt = $conn->prepare($sql);


foreach ($params as $key => $value) {
  $stmt->bindValue($key, $value);
}
$stmt->bindValue(':start', $start, PDO::PARAM_INT);
$stmt->bindValue(':per_page', $per_page, PDO::PARAM_INT);
$stmt->execute();
$destinazioni = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>




<!DOCTYPE html>
<html lang="it">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="../public/css/destinazioni.css" />

  <title>Scopri Destinazioni - IvanTrip</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&display=swap">

</head>
<script>
  function applyFilters() {
    const budget = document.getElementById("budgetSelect").value;
    const type = document.getElementById("typeSelect").value;

    const params = new URLSearchParams();
    if (budget) params.append("budget", budget);
    if (type) params.append("tipologia", type);

    window.location.href = `?${params.toString()}`;
  }
</script>

<div class="navbar">
  <div class="logo">
    <a href="../frontend/html/home.php" style="display: flex; align-items: center; text-decoration: none; color: inherit;">
      <img src="../public/assets/logo.png" alt="Logo" style="width: 48px; height: 48px; margin-right: 10px;">
      <span>IvanTrip - Viaggia Giovane</span>
    </a>
  </div>
  <?php if (isset($_SESSION['utente_id'])): ?>
    <a href="../backend/profilo.php" class="profilo-icon" title="Profilo">
      <img href="../backend/profilo.php" src="../public/assets/user.png" alt="Profilo" style="width: 35px; height: 35px; border-radius: 50%; object-fit: cover;">
    </a>
  <?php else: ?>
    <div class="buttons">
      <button onclick="window.location.href='../frontend/html/login.html'">Accedi</button>
      <button onclick="window.location.href='../frontend/html/register.html'">Registrati</button>
    </div>
  <?php endif; ?>
</div>


<div style="text-align: center; margin-top: 30px;">
  <h1 style="
    display: inline-block;
    background-color: rgba(0, 221, 255, 0.74);  /* grigio trasparente */
    padding: 20px 40px;
    border-radius: 10px;
  ">
    Destinazioni disponibili
  </h1>
</div>

<div class="search-bar">
  <input type="text" placeholder="Destinazione..." id="destinationInput">
  <select id="passengerSelect">
    <option value="">Numero di passeggeri</option>
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3+">3+</option>
  </select>
  <select id="typeSelect">
    <option value="">Tipologia</option>
    <option value="Città">Città</option>
    <option value="Mare">Mare</option>
  </select>

  <select id="budgetSelect">
    <option value="">Budget</option>
    <option value="- €500">- €500</option>
    <option value="€500 - €1000">€500 - €1000</option>
    <option value="€1000+">€1000+</option>
  </select>
  <button onclick="applyFilters()">Cerca</button>
</div>



<div class="destinations-container">
  <?php foreach ($destinazioni as $dest): ?>
    <div class="destination-card">
      <img src="<?= htmlspecialchars($dest['immagine']) ?>" alt="<?= htmlspecialchars($dest['nome']) ?>">
      <div class="destination-info">
        <a href="dettagli_destinazione.php?id=<?= $dest['id_destinazione'] ?>">
          <h3><?= htmlspecialchars($dest['nome']) ?></h3>
        </a>
        <p><?= htmlspecialchars($dest['descrizione']) ?></p>
        <strong>Prezzo al giorno: €<?= number_format($dest['prezzo'], 2) ?></strong>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="pagination">
  <?php
  $queryString = $_GET;
  for ($i = 1; $i <= $total_pages; $i++):
    $queryString['page'] = $i;
    $link = '?' . http_build_query($queryString);
  ?>
    <a href="<?= $link ?>" class="<?= ($i == $page) ? 'active' : '' ?>"><?= $i ?></a>
  <?php endfor; ?>
</div>



<div>
  <br>
  <br>
</div>
<footer>
  <div style="background-color: #333; color: white; padding: 20px 0;">
    <div style="max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center;">
      <div>
        <h3>IvanTrip</h3>
        <p>&copy; 2025 IvanTrip. Tutti i diritti riservati.</p>
      </div>
      <div style="display: flex; gap: 20px;">
        <a href="#" style="color: white; text-decoration: none;">Privacy Policy</a>
        <a href="#" style="color: white; text-decoration: none;">Termini di Servizio</a>
        <a href="#" style="color: white; text-decoration: none;">Contattaci</a>
      </div>
    </div>
  </div>
</footer>
</body>

</html>