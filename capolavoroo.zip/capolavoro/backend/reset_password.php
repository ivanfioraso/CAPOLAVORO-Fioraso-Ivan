<?php
session_start();
require_once('config.php');

if (!isset($_SESSION['codice_verificato']) || $_SESSION['codice_verificato'] !== true) {
    header("Location: forgot_password.php");
    exit();
}

$errore = "";
$successo = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password1 = $_POST['password1'] ?? '';
    $password2 = $_POST['password2'] ?? '';

    if (empty($password1) || empty($password2)) {
        $errore = "Compila entrambi i campi.";
    } elseif ($password1 !== $password2) {
        $errore = "Le password non coincidono.";
    } elseif (strlen($password1) < 6) {
        $errore = "La password deve contenere almeno 6 caratteri.";
    } else {
        // Aggiorna password nel db
        $hash = password_hash($password1, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE utenti SET password = ? WHERE email = ?");
        $stmt->execute([$hash, $_SESSION['email_recupero']]);

        // Pulisci sessione recupero
        session_unset();

        $successo = "Password aggiornata con successo. <a href='../../frontend/html/login.html'>Accedi ora</a>.";
    }
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="../public/css/stileunico.css" />
    <title>Reset Password</title>
</head>
<body>
    <div class="navbar">
        <div class="logo">
            <a href="home.php" style="display: flex; align-items: center; text-decoration: none; color: inherit;">
                <img src="../public/assets/logo.png" alt="Logo" />
                <span>IvanTrip</span>
            </a>
        </div>
    </div>

    <div class="login-container">
        <h2>Reset Password</h2>
        <?php
        if ($errore) {
            echo "<p style='color:red;'>$errore</p>";
        } elseif ($successo) {
            echo "<p style='color:green;'>$successo</p>";
        }
        ?>
        <?php if (!$successo): ?>
        <form method="POST">
            <input type="password" name="password1" placeholder="Nuova password" required /><br /><br />
            <input type="password" name="password2" placeholder="Conferma nuova password" required /><br /><br />
            <button type="submit">Aggiorna Password</button>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
