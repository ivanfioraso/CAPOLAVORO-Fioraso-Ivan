============================================================
                IVANTRIP - SITO DI VIAGGI
============================================================

DESCRIZIONE:

IvanTrip è un sito web per la ricerca e prenotazione di viaggi. Offre funzionalità come:
- Homepage moderna con offerte e destinazioni
- Visualizzazione dettagliata dei viaggi
- Carrello personalizzato per ogni utente
- Gestione utente e cronologia viaggi
- Inserimento e visualizzazione di recensioni
- Sistema di login e sessione PHP

============================================================
            INSTALLAZIONE LOCALE (XAMPP):
============================================================

1. Installa XAMPP e avvia Apache + MySQL.
2. Copia la cartella "progettocapolavoro" in:
   C:\xampp\htdocs\
3. Importa il file `capolavoro.sql` tramite phpMyAdmin nel database `capolavoro`.
4. Accedi dal browser a:
   http://localhost/progettocapolavoro/index.php

============================================================
                 STRUTTURA DEL PROGETTO:
============================================================

/progettocapolavoro
├── /frontend
│   ├── /html          → Pagine HTML/PHP (es. home.php, destinazioni.php)
│   ├── /css           → File CSS personalizzati (stile.css, stilecard.css)
│   └── /img           → Immagini del sito
├── /backend           → Script PHP per login, registrazione, carrello, ecc.
├── /database          → Database capolavoro.sql
├── index.php          → Reindirizza a frontend/html/home.php
└── README.txt         → Questo file

============================================================
               LEGENDA TABELLE DATABASE:
============================================================

1. `utenti`  
   - id (PK), nome, cognome, email, password

2. `destinazioni`  
   - id (PK), nome, descrizione, prezzo, immagine, categoria

3. `carrello`  
   - id_carrello (PK), id_utente (FK), id_destinazione (FK), data_aggiunta

4. `viaggi_completati`  
   - id (PK), user_id (FK), destinazione_id (FK), data_partenza, data_arrivo, prezzo, data_viaggio

5. `recensioni`  
   - id (PK), nome, cognome, voto, commento, data_inserimento

============================================================
                       SCHEMA E-R:
============================================================

ENTITÀ:

1. UTENTI
   - id (PK)
   - nome
   - cognome
   - email (unico)
   - password

2. DESTINAZIONI
   - id (PK)
   - nome
   - descrizione
   - prezzo
   - immagine
   - categoria

3. CARRELLO
   - id_carrello (PK)
   - data_aggiunta

4. VIAGGI_COMPLETATI
   - id (PK)
   - data_partenza
   - data_arrivo
   - prezzo
   - data_viaggio

5. RECENSIONI
   - id (PK)
   - nome
   - cognome
   - voto (1-5)
   - commento
   - data_inserimento

RELAZIONI:

- UTENTI 1 --- ∞ CARRELLO
   Ogni utente può avere più elementi nel carrello.
   CARRELLO contiene le destinazioni aggiunte dall'utente.

- DESTINAZIONI 1 --- ∞ CARRELLO
   Ogni destinazione può essere presente in più carrelli.

- UTENTI 1 --- ∞ VIAGGI_COMPLETATI
   Un utente può avere più viaggi completati.

- DESTINAZIONI 1 --- ∞ VIAGGI_COMPLETATI
   Ogni viaggio completato si riferisce a una singola destinazione.

- UTENTI 1 --- ∞ RECENSIONI
   Un utente può scrivere più recensioni (anche anonime con nome/cognome nei campi recensione).

DIAGRAMMA:

[UTENTI] ──1────∞── [CARRELLO] ──∞────1── [DESTINAZIONI]

[UTENTI] ──1────∞── [VIAGGI_COMPLETATI] ──∞────1── [DESTINAZIONI]

[UTENTI] ──1────∞── [RECENSIONI]

Legenda:
- (PK): Chiave primaria
- 1: uno
- ∞: molti

============================================================